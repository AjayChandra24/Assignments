package Employe;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeService {

	@Autowired
    EmployeDao dao;

    public void createEmployee(List<Employee> emp) {
        dao.saveAll(emp);
    }
 

    public Collection<Employee> getAllEmployees() {
        return dao.findAll();
    }
 

    public Optional<Employee> findEmployeeById(int id) {
        return dao.findById(id);
    }
 

    public void deleteEmployeeById(int id) {
        dao.deleteById(id);
    }

    public void updateEmployee(Employee emp) {
        dao.save(emp);
    }

    public void deleteAllEmployees() {
        dao.deleteAll();
    }
	
}
