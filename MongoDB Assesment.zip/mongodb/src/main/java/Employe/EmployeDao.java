package Employe;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeDao extends MongoRepository<Employee, Integer> {
 
}
